#import "ContactTableViewCell.h"

@implementation ContactTableViewCell

@end

import MEGASdk

extension MEGAError: Error {}
